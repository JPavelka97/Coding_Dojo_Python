from flask import Flask, render_template, request, redirect, session
app = Flask(__name__)  
app.secret_key = 'dojo_survey'

@app.route('/')
def dojo_survey_form():
    return render_template("index.html")

@app.route('/result', methods=["POST"])
def dojo_survey_results():
    session['name']=request.form['name']
    session['dojo_location']=request.form['dojo_location']
    session['language']=request.form['language']
    session['comment']=request.form['comment']
    return render_template("results.html")






if __name__=="__main__":   
    app.run(debug=True)    